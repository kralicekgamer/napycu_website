import tkinter as tk
from tkinter import ttk
import pygame  
import random  

class TypingMachineEditor:
    def __init__(self, root):
        self.root = root
        self.root.title("Psací stroj")

        pygame.mixer.init()

        self.text_widget = tk.Text(root, wrap="none", height=15, width=60, state="disabled")
        self.text_widget.grid(row=0, column=0, sticky="nsew")
        self.text_widget.bind("<Key>", self.handle_key_press)

        self.slider = ttk.Scale(root, from_=0, to=100, orient="horizontal", command=self.slider_moved)
        self.slider.grid(row=1, column=0, sticky="ew")

        self.new_paper_button = tk.Button(root, text="Nový papír", command=self.new_paper)
        self.new_paper_button.grid(row=2, column=0, sticky="ew")

        root.grid_rowconfigure(0, weight=1)
        root.grid_columnconfigure(0, weight=1)

        self.cursor_position = 0
        self.max_slider_value = 100
        self.slider_reset = True  
        self.slider_updating = False 

        self.key_sounds = ["1.wav", "2.wav", "3.wav", "4.wav"]
        self.new_line_sound = "10.wav"

    def slider_moved(self, value):
        if self.slider_updating:
            return 
    
        value = float(value)

        if value == 0 and not self.slider_reset:
            self.text_widget.config(state="normal")
            self.text_widget.insert("insert", "\n")  
            self.text_widget.config(state="disabled")
            self.cursor_position = 0
            self.slider_updating = True
            self.slider.set(self.cursor_position) 
            self.slider_updating = False
            self.slider_reset = True

            self.play_sound(self.new_line_sound)

        elif value > 0:
            self.slider_reset = False  

    def handle_key_press(self, event):
        if len(event.char) == 1:  
            if self.cursor_position < self.max_slider_value:
                self.text_widget.config(state="normal")
                self.text_widget.insert("insert", event.char)
                self.text_widget.config(state="disabled")

                self.cursor_position += 1
                self.slider_updating = True
                self.slider.set(self.cursor_position)  
                self.slider_updating = False

                self.play_random_key_sound()

            else:
                return "break"
        return None

    def play_random_key_sound(self):
        sound_file = random.choice(self.key_sounds)  
        self.play_sound(sound_file)

    def play_sound(self, sound_file):
        try:
            pygame.mixer.music.load(sound_file) 
            pygame.mixer.music.play()  
        except pygame.error as e:
            print(f"Error loading sound: {e}")

    def new_paper(self):
        self.text_widget.config(state="normal")
        self.text_widget.delete(1.0, tk.END)  
        self.text_widget.config(state="disabled")

        self.cursor_position = 0  
        self.slider_reset = True  
        self.slider_updating = True
        self.slider.set(self.cursor_position)  
        self.slider_updating = False

        self.play_sound(self.new_line_sound)

if __name__ == "__main__":
    root = tk.Tk()
    app = TypingMachineEditor(root)
    root.mainloop()
